#!/usr/bin/env python3

# This script demonstrates the usage, capability and features of the library.
from imutils.video import VideoStream
from imutils import face_utils
from threading import Thread
import numpy as np
import argparse
import imutils
import time
import dlib
import cv2
import os
from scipy.spatial import distance as dist
from twilio.rest import Client
import spidev
import time
import ddd
from ddd import eye_aspect_ratio, final_ear, lip_distance
import touch_sensing
from touch_sensing import readadc
#import time

import argparse
import subprocess
import time
import os
from datetime import datetime

from bluepy.btle import BTLEDisconnectError

#from constants import MUSICSTATE
from miband import miband

parser = argparse.ArgumentParser()
parser.add_argument('-m', '--mac', required=False, help='Set mac address of the device')
parser.add_argument('-k', '--authkey', required=False, help='Set Auth Key for the device')
args = parser.parse_args()

hr_data = None
MAC_ADDR = "EE:33:7D:B7:D0:16"
# Use appropriate MAC
AUTH_KEY = "0f4fd053cc1dc3e2e7096b83a22ebb51"

#message definition
TWILIO_ACCOUNT_SID = 'ACa421f63a5bb63cf4a3e34d0fc8fbcf45' # replace with your Account SID
TWILIO_AUTH_TOKEN = 'c83f519763bdb8361fc5c98196676c6c' # replace with your Auth Token
TWILIO_PHONE_SENDER = "+13613217489" # replace with the phone number you registered in twilio
TWILIO_PHONE_RECIPIENT = "+918310484969" # replace with your phone number

client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)


# Convert Auth Key from hex to byte format
if AUTH_KEY:
    AUTH_KEY = bytes.fromhex(AUTH_KEY)

def send_notif():
    msg = "Drowsy alert"
    ty= 1
    a=[5,4,3]
    band.send_custom_alert(a[ty-1],msg)

# Needs Auth
def get_heart_rate():
    print ('Latest heart rate : %i' % band.get_heart_rate_one_time())

ap = argparse.ArgumentParser()
ap.add_argument("-w", "--webcam", type=int, default=0, help="index of webcam on system")
args = vars(ap.parse_args())

detector = cv2.CascadeClassifier("/home/pi/Downloads/haarcascade_frontalface_default.xml")    #Faster but less accurate
predictor = dlib.shape_predictor('/home/pi/Downloads/shape_predictor_68_face_landmarks.dat')

print("-> Starting Video Stream")
vs= VideoStream(usePiCamera=True).start()
time.sleep(1.0)

def heart_logger(data):
    EYE_AR_THRESH = 0.30
    EYE_AR_CONSEC_FRAMES = 5
    YAWN_THRESH = 17
    YAWN_TH_CONSEC_FRAMES = 8
    HEART_RV_CONSEC_FRAMES = 10
    TOUCH_S_CONSEC_FRAMES = 20
    ECOUNTER = 0
    EALERT = 0
    YCOUNTER = 0
    YALERT = 0
    HCOUNTER = 0
    HALERT = 0
    PCOUNTER = 0
    PALERT = 0
    pad_channel = 0
    ALLALERT = 0
    while True:
        frame = vs.read()
        frame = imutils.resize(frame, width=450)
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    #rects = detector(gray, 0)

        rects = detector.detectMultiScale(gray, scaleFactor=1.1, 
                minNeighbors=5, minSize=(30, 30),
                flags=cv2.CASCADE_SCALE_IMAGE)
        
    #for rect in rects:
        for (x, y, w, h) in rects:
            rect = dlib.rectangle(int(x), int(y), int(x + w),int(y + h))
            shape = predictor(gray, rect)
            shape = face_utils.shape_to_np(shape)
            eye = final_ear(shape)
            ear = eye[0]
            leftEye = eye [1]
            rightEye = eye[2]

            distance = lip_distance(shape)
            leftEyeHull = cv2.convexHull(leftEye)
            rightEyeHull = cv2.convexHull(rightEye)

            cv2.drawContours(frame, [leftEyeHull], -1, (0, 255, 0), 1)
            cv2.drawContours(frame, [rightEyeHull], -1, (0, 255, 0), 1)
            lip = shape[48:60]
            cv2.drawContours(frame, [lip], -1, (0, 255, 0), 1)

            if ear <= EYE_AR_THRESH:
                ECOUNTER += 1
                if ECOUNTER >= EYE_AR_CONSEC_FRAMES:
                    cv2.putText(frame, "DROWSINESS ALERT!", (10, 30),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
                    os.system('espeak -s 170 "You seem drowsy! open eyes"')
                    send_notif()
                    EALERT = EALERT + 1
                
            else:
                ECOUNTER = 0
                EALERT = 0

            if (distance > YAWN_THRESH):
                YCOUNTER +=1
                if YCOUNTER >= YAWN_TH_CONSEC_FRAMES:
                    cv2.putText(frame, "YAWN Alert", (10, 60),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
                    os.system('espeak -s 170 "You seem drowsy! Yawn alert"')
                    send_notif()
                    YALERT = YALERT + 1
                
            else:
                YCOUNTER = 0
                YALERT = 0
            #buzzState = False
            
            if data < 70:
                HCOUNTER +=1
                if HCOUNTER >= HEART_RV_CONSEC_FRAMES:
                    cv2.putText(frame, "HEART RATE ALERT!", (10, 90),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
                    os.system('espeak -s 170 "You seem drowsy! Low heart rate alert"')
                    send_notif()
                    HALERT = HALERT + 1    
        
            else:
                HCOUNTER = 0
                HALERT = 0
                
            pad_value = readadc(pad_channel)
            if pad_value < 1015:
                PCOUNTER += 1
                if PCOUNTER >= TOUCH_S_CONSEC_FRAMES:
                    cv2.putText(frame, "GRIP ALERT!", (10, 120),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
                    os.system('espeak -s 170 "You seem drowsy! Steering grip alert"')
                    send_notif()
                    PALERT = PALERT + 1
                #time.sleep(delay)
            
            else:
                PCOUNTER = 0
                PALERT = 0
                
                
            cv2.putText(frame, "EAR: {:.2f}".format(ear), (300, 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
            cv2.putText(frame, "YAWN: {:.2f}".format(distance), (300, 60),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
        
            ALLALERT = EALERT+YALERT+HALERT+PALERT
            Average = ALLALERT/4
            if(Average > 3):
                for i in range(3):
                    message = client.messages.create(
                        to=TWILIO_PHONE_RECIPIENT,
                        from_=TWILIO_PHONE_SENDER,
                        body="The person is very drowsy. Please take some action")
                Average = 0
            
            else:
                ALLALERT = 0
            

        cv2.imshow("Frame", frame)
        key = cv2.waitKey(1) & 0xFF
        if key == ord("q"):
            break
        
        

# Needs Auth
def get_realtime():
    band.start_heart_rate_realtime(heart_measure_callback=heart_logger)

if __name__ == "__main__":
    success = False
    while not success:
        try:
            if (AUTH_KEY):
                band = miband(MAC_ADDR, AUTH_KEY, debug=True)
                success = band.initialize()
            else:
                band = miband(MAC_ADDR, debug=True)
                success = True
            break
        except BTLEDisconnectError:
            print('Connection to the MIBand failed. Trying out again in 3 seconds')
            time.sleep(3)
            continue
        except KeyboardInterrupt:
            print("\nExit.")
            exit()

get_heart_rate()
get_realtime()
cv2.destroyAllWindows()
vs.stop()
#GPIO.cleanup()

